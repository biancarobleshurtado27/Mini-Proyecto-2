# Configuración externa pendiente

Esta es la única configuración que no puede completarse sin credenciales del propietario del proyecto.

## Google Drive

1. En Google Cloud Console, habilitar **Google Drive API** en el proyecto del Mini Proyecto #1 o crear uno nuevo.
2. Crear una cuenta de servicio y descargar su JSON.
3. Guardar ese archivo como `service-account.json` en la raíz del repositorio. El archivo está ignorado por Git.
4. Crear una carpeta de Drive para las políticas y compartirla con el correo de la cuenta de servicio, con permiso de **Editor**. Ese permiso permite indexar y cargar los entregables desde el portal.
5. Subir los 12 documentos de `docs/policies/`, el PDF de `output/pdf/` y una hoja de cálculo/Google Sheet.
6. Copiar el ID de la carpeta desde la URL de Drive. También puede pegar la URL completa: el servidor extraerá el ID automáticamente.

## API de DeepSeek

1. Crear una clave API en la plataforma de DeepSeek.
2. Copiar `.env.example` a `.env`.
3. Definir `DEEPSEEK_API_KEY` y `GOOGLE_DRIVE_FOLDER_ID`.
4. No comparta ni pegue las claves en el chat ni las suba a Git.

DeepSeek se usa para redactar respuestas basadas en el contexto recuperado. La búsqueda local funciona sin clave. Si se implementa pgvector con embeddings reales, se elegirá un proveedor o modelo de embeddings compatible por separado.

## Prueba posterior

En una carpeta normal de Mi unidad, la cuenta de servicio no posee cuota de almacenamiento aunque tenga permiso de Editor. Por eso el PDF y la hoja de cálculo se deben subir manualmente a la carpeta, tal como se hizo con las políticas. El endpoint `POST /api/ingestion/upload-deliverables` queda disponible para unidades compartidas de Google Workspace. Luego un usuario RRHH debe llamar `POST /api/ingestion/sync`; la respuesta debe devolver los conteos `indexed`, `updated` y `files_seen`.
