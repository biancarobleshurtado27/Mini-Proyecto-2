export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api'
export async function api(path, options = {}, token) {
  const response = await fetch(`${API_URL}${path}`, { ...options, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers } })
  const data = await response.json()
  if (!response.ok) throw new Error(data.detail || 'Ocurrió un error')
  return data
}
